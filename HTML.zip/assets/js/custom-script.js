



$('#get-pawword').click(function () {
    $('#email-password').hide();
    $('#mobile-otp').show();
});

$('#get-email').click(function () {
    $('#email-password').show();
    $('#mobile-otp').hide();
});


$('#get-login').click(function () {
    $('#mobile-otp').hide();
    $('#enter-otp').show();
});


// Report Page - Input check uncheck

// write if else condition for input checkbox ? 

if ($("#switch:checkbox:checked").length == 0) {

    $("#switch").change(function () {
        $("input:checkbox").prop('checked', $(this).prop("checked"));
    });

    $("#switch:checkbox").change(function () {
        if ($("#switch:checkbox:checked").length == 0) {
            //alert('if')
            $('.span-yes').hide();
            $('.span-no').show();

        } else {
            // alert('else');
            $('.span-yes').show();
            $('.span-no').hide();
        }
    });

}
 
$('.menu-icons-btn').click(function(){
    $('.user-names-top').toggleClass('show-menus-kid');
    $(this).toggleClass('close-menu-kid')
});